import { useEffect } from "react";
import { View, ActivityIndicator } from "react-native";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useAuth } from "../context/AuthContext";
import { colors } from "../theme";

import HomeScreen from "../screens/HomeScreen";
import LoginScreen from "../screens/LoginScreen";
import CadastroScreen from "../screens/CadastroScreen";
import SalasScreen from "../screens/SalasScreen";
import GradeScreen from "../screens/GradeScreen";
import NovaSalaScreen from "../screens/NovaSalaScreen";
import ConfigSalaScreen from "../screens/ConfigSalaScreen";
import CadastrosScreen from "../screens/CadastrosScreen";
import PainelProfessorScreen from "../screens/PainelProfessorScreen";

const Stack = createNativeStackNavigator();
const ADMIN = ["escola", "administrador"];

// Substitui o <ProtectedRoute> do react-router: bloqueia a tela e manda para
// login/salas quando o usuário não tem permissão, igual ao original.
function protect(Component, roles) {
  return function Protected(props) {
    const { user, tipo, loading } = useAuth();
    useEffect(() => {
      if (loading) return;
      if (!user) { props.navigation.replace("Login"); return; }
      if (roles && !roles.includes(tipo)) { props.navigation.replace("Salas"); }
    }, [user, tipo, loading]);

    if (loading || !user || (roles && !roles.includes(tipo))) {
      return (
        <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={colors.neonLime} />
        </View>
      );
    }
    return <Component {...props} />;
  };
}

const NovaSalaProtected = protect(NovaSalaScreen, ADMIN);
const ConfigSalaProtected = protect(ConfigSalaScreen, ADMIN);
const CadastrosProtected = protect(CadastrosScreen, ADMIN);
const PainelProfessorProtected = protect(PainelProfessorScreen, ["professor"]);

const navTheme = {
  ...DarkTheme,
  colors: { ...DarkTheme.colors, background: colors.bg, card: colors.bgCarbon, border: colors.border, primary: colors.neonLime },
};

export default function AppNavigator() {
  return (
    <NavigationContainer theme={navTheme}>
      <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Cadastro" component={CadastroScreen} />
        <Stack.Screen name="Salas" component={SalasScreen} />
        <Stack.Screen name="Grade" component={GradeScreen} />
        <Stack.Screen name="NovaSala" component={NovaSalaProtected} />
        <Stack.Screen name="ConfigSala" component={ConfigSalaProtected} />
        <Stack.Screen name="Cadastros" component={CadastrosProtected} />
        <Stack.Screen name="PainelProfessor" component={PainelProfessorProtected} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
