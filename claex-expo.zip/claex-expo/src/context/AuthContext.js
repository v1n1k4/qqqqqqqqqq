import { createContext, useContext, useState, useCallback, useEffect } from "react";
import { API } from "../api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const u = await API.hydrateSession();
      setUser(u);
      setLoading(false);
    })();
  }, []);

  // Chame após um login bem-sucedido (API.login já grava a sessão no AsyncStorage)
  const refresh = useCallback(() => setUser(API.getUsuarioAtual()), []);

  const logout = useCallback(async () => {
    await API.logout();
    setUser(null);
  }, []);

  const tipo = user ? (user.tipo || "").toLowerCase() : null;

  return (
    <AuthContext.Provider value={{ user, tipo, loading, refresh, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
