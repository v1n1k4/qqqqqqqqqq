// Paleta extraída do style.css / pages.css originais do CLAEX (tema "racing" neon escuro).
export const colors = {
  bg: "#0a0a0a",
  bgCarbon: "#111214",
  bgSurface: "#161719",
  border: "rgba(255,255,255,0.08)",
  borderLime: "rgba(210,255,0,0.35)",
  neonLime: "#D2FF00",
  neonCyan: "#00F0FF",
  neonRed: "#FF3B30",
  textPure: "#FFFFFF",
  textPrimary: "#E6E6E6",
  textSecondary: "#A0A0A0",
  textMuted: "#6b6b6b",
};

export const radius = { sm: 8, md: 14, lg: 20, xs: 6 };

export const fonts = {
  mono: "monospace",
};

export const commonStyles = {
  screen: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  card: {
    backgroundColor: colors.bgSurface,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: 20,
  },
  tag: {
    alignSelf: "flex-start",
    backgroundColor: "rgba(210,255,0,0.08)",
    borderColor: colors.borderLime,
    borderWidth: 1,
    borderRadius: 999,
    paddingVertical: 4,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  tagText: {
    color: colors.neonLime,
    fontSize: 11,
    fontFamily: fonts.mono,
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  title: {
    color: colors.textPure,
    fontSize: 26,
    fontWeight: "800",
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    marginTop: 6,
  },
  label: {
    color: colors.textSecondary,
    fontSize: 12,
    marginBottom: 6,
    textTransform: "uppercase",
  },
  input: {
    backgroundColor: colors.bgCarbon,
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: radius.sm,
    color: colors.textPure,
    paddingVertical: 12,
    paddingHorizontal: 14,
    fontSize: 15,
    marginBottom: 14,
  },
  btnNeon: {
    backgroundColor: colors.neonLime,
    borderRadius: 999,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  btnNeonText: {
    color: "#000",
    fontWeight: "800",
    textTransform: "uppercase",
    fontSize: 14,
    letterSpacing: 0.5,
  },
  btnGhost: {
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 999,
    paddingVertical: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  btnGhostText: {
    color: colors.textPure,
    fontWeight: "700",
    fontSize: 14,
  },
  errorBox: {
    backgroundColor: "rgba(255,59,48,0.15)",
    borderColor: colors.neonRed,
    borderWidth: 1,
    borderRadius: radius.sm,
    padding: 12,
    marginBottom: 12,
  },
  errorText: {
    color: "#ff9999",
    fontSize: 13,
    textAlign: "center",
    fontFamily: fonts.mono,
  },
};
