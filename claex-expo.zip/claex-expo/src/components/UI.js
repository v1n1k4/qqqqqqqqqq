import { Text, View, TextInput, TouchableOpacity, ActivityIndicator } from "react-native";
import { Picker } from "@react-native-picker/picker";
import { colors, commonStyles as s } from "../theme";

export function Tag({ children }) {
  return (
    <View style={s.tag}>
      <Text style={s.tagText}>{children}</Text>
    </View>
  );
}

export function NeonButton({ title, onPress, loading, disabled, style }) {
  return (
    <TouchableOpacity
      style={[s.btnNeon, (disabled || loading) && { opacity: 0.6 }, style]}
      onPress={onPress}
      disabled={disabled || loading}
    >
      {loading ? <ActivityIndicator color="#000" /> : <Text style={s.btnNeonText}>{title}</Text>}
    </TouchableOpacity>
  );
}

export function GhostButton({ title, onPress, style, textStyle }) {
  return (
    <TouchableOpacity style={[s.btnGhost, style]} onPress={onPress}>
      <Text style={[s.btnGhostText, textStyle]}>{title}</Text>
    </TouchableOpacity>
  );
}

export function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 4 }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TextInput
        placeholderTextColor={colors.textMuted}
        style={s.input}
        {...props}
      />
    </View>
  );
}

export function SelectField({ label, selectedValue, onValueChange, items, enabled = true }) {
  return (
    <View style={{ marginBottom: 4 }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <View style={[s.input, { paddingVertical: 0, paddingHorizontal: 0 }]}>
        <Picker
          selectedValue={selectedValue}
          onValueChange={onValueChange}
          enabled={enabled}
          dropdownIconColor={colors.textPure}
          style={{ color: colors.textPure }}
          itemStyle={{ color: colors.textPure }}
        >
          {items.map((it) => (
            <Picker.Item key={String(it.value)} label={it.label} value={it.value} />
          ))}
        </Picker>
      </View>
    </View>
  );
}

export function ErrorBox({ children }) {
  if (!children) return null;
  return (
    <View style={s.errorBox}>
      <Text style={s.errorText}>{children}</Text>
    </View>
  );
}

export function ScreenTitle({ children }) {
  return <Text style={s.title}>{children}</Text>;
}
