import { useState } from "react";
import { View, Text, TouchableOpacity, Modal, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../context/AuthContext";
import { colors } from "../theme";

export function useVisibilidade() {
  const { tipo } = useAuth();
  return {
    novaSala: tipo !== "aluno" && tipo !== "professor",
    configSala: tipo !== "aluno",
    cadastros: tipo !== "aluno" && tipo !== "professor",
    painelProf: tipo === "professor",
  };
}

function SideMenuLink({ label, onPress }) {
  return (
    <TouchableOpacity style={menuStyles.link} onPress={onPress}>
      <Text style={menuStyles.linkText}>{label}</Text>
    </TouchableOpacity>
  );
}

export default function Header({ telemetry }) {
  const [open, setOpen] = useState(false);
  const navigation = useNavigation();
  const { user, tipo, logout } = useAuth();
  const v = useVisibilidade();

  const go = (screen, params) => {
    setOpen(false);
    navigation.navigate(screen, params);
  };

  const sair = async () => {
    setOpen(false);
    await logout();
    navigation.navigate("Login");
  };

  return (
    <>
      <View style={headerStyles.header}>
        <TouchableOpacity onPress={() => setOpen(true)} style={headerStyles.menuBtn}>
          <View style={headerStyles.bar} />
          <View style={headerStyles.bar} />
          <View style={headerStyles.bar} />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => go("Home")}>
          <Text style={headerStyles.brand}>
            CLAEX<Text style={{ color: colors.neonLime }}>.</Text>
          </Text>
        </TouchableOpacity>

        <Text style={headerStyles.telemetry} numberOfLines={1}>
          [{telemetry}]
        </Text>
      </View>

      <Modal visible={open} animationType="slide" transparent onRequestClose={() => setOpen(false)}>
        <TouchableOpacity style={menuStyles.overlay} activeOpacity={1} onPress={() => setOpen(false)} />
        <View style={menuStyles.panel}>
          <View style={menuStyles.panelHeader}>
            <Text style={headerStyles.brand}>
              CLAEX<Text style={{ color: colors.neonLime }}>.</Text>
            </Text>
            <TouchableOpacity onPress={() => setOpen(false)}>
              <Text style={{ color: colors.textPure, fontSize: 20 }}>✕</Text>
            </TouchableOpacity>
          </View>

          {user ? (
            <Text style={menuStyles.userLine}>
              {user.nome} ({(user.tipo || "").toUpperCase()})
            </Text>
          ) : null}

          <Text style={menuStyles.sectionTag}>NAVEGAÇÃO RÁPIDA</Text>
          <SideMenuLink label="🏠 Início" onPress={() => go("Home")} />
          {!user && <SideMenuLink label="🔑 Acesso / Login" onPress={() => go("Login")} />}
          {!user && <SideMenuLink label="📝 Cadastre-se" onPress={() => go("Cadastro")} />}
          {user && <SideMenuLink label="📚 Salas & Turmas" onPress={() => go("Salas")} />}
          {user && v.novaSala && <SideMenuLink label="➕ Criar Nova Sala" onPress={() => go("NovaSala")} />}
          {user && v.cadastros && <SideMenuLink label="👥 Painel de Professores" onPress={() => go("Cadastros")} />}
          {user && v.painelProf && <SideMenuLink label="🎓 Meu Painel" onPress={() => go("PainelProfessor")} />}
          {user && <SideMenuLink label="🚪 Sair" onPress={sair} />}
        </View>
      </Modal>
    </>
  );
}

const headerStyles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    backgroundColor: colors.bgCarbon,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 12,
  },
  menuBtn: { gap: 4, padding: 4 },
  bar: { width: 20, height: 2, backgroundColor: colors.textPure },
  brand: { color: colors.textPure, fontSize: 18, fontWeight: "800" },
  telemetry: {
    color: colors.textMuted,
    fontFamily: "monospace",
    fontSize: 11,
    marginLeft: "auto",
    flexShrink: 1,
  },
});

const menuStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)" },
  panel: {
    position: "absolute",
    top: 0,
    bottom: 0,
    left: 0,
    width: "78%",
    backgroundColor: colors.bgSurface,
    padding: 20,
    paddingTop: 60,
  },
  panelHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  userLine: {
    color: colors.neonLime,
    fontFamily: "monospace",
    fontSize: 12,
    marginBottom: 16,
  },
  sectionTag: {
    color: colors.textMuted,
    fontSize: 11,
    textTransform: "uppercase",
    marginBottom: 8,
  },
  link: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  linkText: { color: colors.textPrimary, fontSize: 15 },
});
