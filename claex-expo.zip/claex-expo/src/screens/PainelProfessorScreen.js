import { useCallback, useEffect, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import Header from "../components/Header";
import { NeonButton, Field, SelectField } from "../components/UI";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const DIAS = ["Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"];
const MATERIAS_EM = [
  "Português", "Matemática", "Física", "Química", "Biologia", "História", "Geografia",
  "Sociologia", "Filosofia", "Educação Física", "Artes", "Língua Inglesa", "Língua Espanhola",
];
const DISP_VAZIA = { diaSemana: DIAS[0], horarioInicial: "", horarioFinal: "", modalidade: "Presencial", observacao: "" };
const MAT_VAZIA = { select: "", custom: "", nivel: "", exp: "" };

function TabButton({ label, active, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ paddingVertical: 10, paddingHorizontal: 4, marginRight: 20, borderBottomWidth: 2, borderBottomColor: active ? colors.neonLime : "transparent" }}>
      <Text style={{ color: active ? colors.neonLime : colors.textSecondary, fontWeight: active ? "700" : "500" }}>{label}</Text>
    </TouchableOpacity>
  );
}

export default function PainelProfessorScreen() {
  const [aba, setAba] = useState("salas");
  const [salas, setSalas] = useState([]);
  const [disps, setDisps] = useState([]);
  const [materias, setMaterias] = useState([]);
  const [disp, setDisp] = useState(DISP_VAZIA);
  const [mat, setMat] = useState(MAT_VAZIA);
  const [vinculando, setVinculando] = useState(false);

  const carregarDisponibilidades = useCallback(async () => {
    try { setDisps(await API.professor.listarDisponibilidade()); } catch { /* ignora */ }
  }, []);
  const carregarMaterias = useCallback(async () => {
    try { setMaterias(await API.professor.listarMaterias()); } catch { /* ignora */ }
  }, []);

  useEffect(() => {
    carregarDisponibilidades();
    carregarMaterias();
    API.salas.listar().then((sList) => setSalas(sList || [])).catch(() => {});
  }, [carregarDisponibilidades, carregarMaterias]);

  const setD = (c) => (v) => setDisp((d) => ({ ...d, [c]: v }));
  const setM = (c) => (v) => setMat((m) => ({ ...m, [c]: v }));

  const cadastrarDisp = async () => {
    if (!disp.horarioInicial || !disp.horarioFinal) {
      Alert.alert("Atenção", "Preencha o horário inicial e final.");
      return;
    }
    const res = await API.professor.cadastrarDisponibilidade(disp);
    if (res.ok) {
      Alert.alert("Sucesso", "Disponibilidade cadastrada com sucesso!");
      setDisp(DISP_VAZIA);
      carregarDisponibilidades();
    } else {
      Alert.alert("Erro", "Erro ao cadastrar disponibilidade.");
    }
  };

  const deletarDisp = (id) => {
    Alert.alert("Confirmar", "Confirma a remoção deste intervalo?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Remover", style: "destructive", onPress: async () => {
          const res = await API.professor.deletarDisponibilidade(id);
          if (res.ok) carregarDisponibilidades();
          else Alert.alert("Erro", "Erro ao remover registro.");
        }
      },
    ]);
  };

  const vincularMateria = async () => {
    const nomeMateria = mat.select === "__outra__" ? mat.custom.trim() : mat.select;
    if (!nomeMateria) {
      Alert.alert("Atenção", "Selecione uma matéria da lista ou digite o nome de uma nova.");
      return;
    }
    setVinculando(true);
    try {
      const res = await API.professor.vincularMateria({ nomeMateria, nivelEnsino: mat.nivel.trim(), experiencia: mat.exp.trim() });
      if (res.ok) {
        Alert.alert("Sucesso", "Matéria vinculada com sucesso!");
        setMat(MAT_VAZIA);
        carregarMaterias();
      } else {
        Alert.alert("Erro", "Erro ao vincular matéria.");
      }
    } catch (err) {
      Alert.alert("Erro", "Erro de comunicação com o servidor: " + err.message);
    } finally {
      setVinculando(false);
    }
  };

  return (
    <View style={s.screen}>
      <Header telemetry="PAINEL DO PROFESSOR" />
      <View style={{ flexDirection: "row", paddingHorizontal: 20, paddingTop: 14, borderBottomWidth: 1, borderBottomColor: colors.border }}>
        <TabButton label="Salas" active={aba === "salas"} onPress={() => setAba("salas")} />
        <TabButton label="Disponibilidade" active={aba === "disponibilidade"} onPress={() => setAba("disponibilidade")} />
        <TabButton label="Matérias" active={aba === "materias"} onPress={() => setAba("materias")} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 20 }}>
        {aba === "salas" && (
          <>
            <Text style={{ color: colors.textPure, fontSize: 18, fontWeight: "700", marginBottom: 6 }}>Salas & Turmas Vinculadas</Text>
            <Text style={{ color: colors.textSecondary, marginBottom: 16 }}>Visualização restrita às turmas vinculadas ao seu perfil.</Text>
            {salas.map((sl) => (
              <View key={sl.id_sala} style={[s.card, { marginBottom: 10 }]}>
                <Text style={{ color: colors.textMuted, fontSize: 11, marginBottom: 4 }}>SALA #{sl.id_sala}</Text>
                <Text style={{ color: colors.textPure, fontWeight: "700" }}>{sl.nome_sala}</Text>
              </View>
            ))}
          </>
        )}

        {aba === "disponibilidade" && (
          <>
            <Text style={{ color: colors.textPure, fontSize: 18, fontWeight: "700", marginBottom: 12 }}>Gestão de Disponibilidade</Text>
            <View style={[s.card, { marginBottom: 20 }]}>
              <SelectField label="Dia da Semana" selectedValue={disp.diaSemana} onValueChange={setD("diaSemana")} items={DIAS.map((d) => ({ label: d, value: d }))} />
              <Field label="Horário Inicial" placeholder="08:00" value={disp.horarioInicial} onChangeText={setD("horarioInicial")} />
              <Field label="Horário Final" placeholder="12:00" value={disp.horarioFinal} onChangeText={setD("horarioFinal")} />
              <SelectField label="Modalidade" selectedValue={disp.modalidade} onValueChange={setD("modalidade")} items={[{ label: "Presencial", value: "Presencial" }, { label: "On-line", value: "On-line" }, { label: "Ambas", value: "Ambas" }]} />
              <Field label="Observação (Opcional)" placeholder="Ex: Preferência por aulas no bloco A" value={disp.observacao} onChangeText={setD("observacao")} />
              <NeonButton title="+ Cadastrar Horário" onPress={cadastrarDisp} style={{ marginTop: 8 }} />
            </View>

            {disps.map((d) => (
              <View key={d.id} style={[s.card, { marginBottom: 10 }]}>
                <Text style={{ color: colors.textPure, fontWeight: "700" }}>{d.diaSemana}</Text>
                <Text style={{ color: colors.textSecondary, fontSize: 13 }}>{d.horarioInicial} — {d.horarioFinal} • {d.modalidade}</Text>
                {!!d.observacao && <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 4 }}>{d.observacao}</Text>}
                <TouchableOpacity onPress={() => deletarDisp(d.id)} style={{ marginTop: 8 }}>
                  <Text style={{ color: "#ff6666" }}>🗑️ Remover</Text>
                </TouchableOpacity>
              </View>
            ))}
          </>
        )}

        {aba === "materias" && (
          <>
            <Text style={{ color: colors.textPure, fontSize: 18, fontWeight: "700", marginBottom: 12 }}>Minhas Matérias</Text>
            <View style={[s.card, { marginBottom: 20 }]}>
              <SelectField
                label="Matéria"
                selectedValue={mat.select}
                onValueChange={setM("select")}
                items={[{ label: "Selecione uma matéria do Ensino Médio", value: "" }, ...MATERIAS_EM.map((m) => ({ label: m, value: m })), { label: "✏️ Outra matéria (digitar)", value: "__outra__" }]}
              />
              {mat.select === "__outra__" && (
                <Field placeholder="Digite o nome da matéria" value={mat.custom} onChangeText={setM("custom")} />
              )}
              <Field label="Nível de Ensino" placeholder="Ex: Médio / Superior" value={mat.nivel} onChangeText={setM("nivel")} />
              <Field label="Experiência" placeholder="Ex: 5 anos" value={mat.exp} onChangeText={setM("exp")} />
              <NeonButton title={vinculando ? "Vinculando..." : "Vincular Matéria"} onPress={vincularMateria} loading={vinculando} style={{ marginTop: 8 }} />
            </View>

            {materias.map((m, i) => (
              <View key={m.id ?? i} style={[s.card, { marginBottom: 10 }]}>
                <Text style={{ color: colors.textPure, fontWeight: "700" }}>{m.nomeMateria}</Text>
                <Text style={{ color: colors.textSecondary, fontFamily: "monospace", fontSize: 12 }}>{m.nivelEnsino} • {m.experiencia}</Text>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}
