import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, Field, SelectField, ErrorBox } from "../components/UI";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const TIPOS = [
  { label: "Instituição / Escola", value: "escola" },
  { label: "Professor / Docente", value: "professor" },
  { label: "Aluno / Estudante", value: "aluno" },
];

export default function CadastroScreen({ navigation }) {
  const [form, setForm] = useState({ nome: "", email: "", senha: "", tipo: "escola" });
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (campo) => (valor) => setForm((f) => ({ ...f, [campo]: valor }));

  const concluir = async () => {
    const nome = form.nome.trim();
    const email = form.email.trim();
    const senha = form.senha.trim();

    if (!nome || !email || !senha) {
      setErro("Preencha todos os campos para continuar!");
      return;
    }

    setErro("");
    setLoading(true);
    try {
      const result = await API.cadastros.salvar(nome, email, senha, form.tipo);
      if (result.ok) {
        Alert.alert("Sucesso", "Cadastro realizado e salvo no banco de dados com sucesso!");
        navigation.navigate("Login");
        return;
      }
      setErro("Erro ao cadastrar: " + (result.msg || "Verifique os dados informados."));
    } catch (e) {
      setErro("Falha ao conectar com o banco de dados. Verifique a URL do backend.");
    }
    setLoading(false);
  };

  return (
    <View style={s.screen}>
      <Header telemetry="CADASTRO // NOVO USUÁRIO" />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Tag>[Registro de Entidade]</Tag>
        <Text style={[s.title, { fontSize: 30, marginBottom: 10 }]}>
          Junte-se à <Text style={{ color: colors.neonLime }}>CLAEX</Text>
        </Text>
        <Text style={{ color: colors.textSecondary, marginBottom: 24 }}>
          Cadastre sua instituição de ensino, perfil de professor ou estudante para sincronizar disponibilidades semanais.
        </Text>

        <View style={[s.card, { marginBottom: 20 }]}>
          <Tag>Formulário de Cadastro</Tag>
          <Text style={{ color: colors.textPure, fontSize: 20, fontWeight: "700", marginBottom: 16 }}>
            Criar Nova Conta
          </Text>

          <Field label="Nome Completo / Instituição" placeholder="Ex: Escola Estadual ou Prof. Carlos"
            value={form.nome} onChangeText={set("nome")} />
          <Field label="E-mail" placeholder="seuemail@exemplo.com" value={form.email}
            onChangeText={set("email")} autoCapitalize="none" keyboardType="email-address" />
          <Field label="Senha de Acesso" placeholder="Crie uma senha segura" value={form.senha}
            onChangeText={set("senha")} secureTextEntry />
          <SelectField label="Tipo de Perfil" selectedValue={form.tipo} onValueChange={set("tipo")} items={TIPOS} />

          <ErrorBox>{erro}</ErrorBox>

          <NeonButton
            title={loading ? "Gravando..." : "Concluir Cadastro"}
            onPress={concluir}
            loading={loading}
            style={{ marginTop: 8 }}
          />

          <TouchableOpacity onPress={() => navigation.navigate("Login")} style={{ marginTop: 16 }}>
            <Text style={{ color: colors.textSecondary, textAlign: "center" }}>
              Já possui uma conta?{" "}
              <Text style={{ color: colors.neonLime, fontWeight: "700" }}>Faça login aqui</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}
