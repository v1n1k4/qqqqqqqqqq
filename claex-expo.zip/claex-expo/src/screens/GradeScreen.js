import { useCallback, useEffect, useMemo, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, GhostButton } from "../components/UI";
import { useAuth } from "../context/AuthContext";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const DIAS = ["SEGUNDA", "TERÇA", "QUARTA", "QUINTA", "SEXTA"];
const COL_WIDTH = 130;
const HORA_WIDTH = 70;

const formatarHora = (h) => (h ? h.substring(0, 5) : "08:00");

function adicionarMinutos(horaStr, minutos) {
  const [hs, ms] = horaStr.split(":");
  let h = parseInt(hs, 10) || 0;
  let m = (parseInt(ms, 10) || 0) + minutos;
  h = (h + Math.floor(m / 60)) % 24;
  m = m % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function montarLinhas(sala, matriz) {
  const quant = sala?.quant_aula || 5;
  const duracao = sala?.duracao_aula || 50;
  let hora = sala?.inicio_aula ? formatarHora(sala.inicio_aula) : "07:30";
  const linhas = [];
  for (let periodo = 0; periodo < quant; periodo++) {
    linhas.push({ tipo: "aula", hora, aulas: DIAS.map((_, dia) => (matriz[dia] || [])[periodo] || null) });
    hora = adicionarMinutos(hora, duracao);
    if (periodo === Math.floor(quant / 2) - 1 && sala?.duracao_intervalo) {
      linhas.push({ tipo: "intervalo", hora, duracao: sala.duracao_intervalo });
      hora = adicionarMinutos(hora, sala.duracao_intervalo);
    }
  }
  return linhas;
}

export default function GradeScreen({ route, navigation }) {
  const { id } = route.params || {};
  const { tipo } = useAuth();

  const [sala, setSala] = useState(null);
  const [erroSala, setErroSala] = useState(false);
  const [matriz, setMatriz] = useState(null);
  const [gradeErro, setGradeErro] = useState(false);
  const [gerando, setGerando] = useState(false);

  const carregarGrade = useCallback(async (idSala) => {
    try {
      const m = await API.grade.buscar(idSala);
      setMatriz(m && m.length ? m : []);
      setGradeErro(false);
    } catch {
      setMatriz([]);
      setGradeErro(true);
    }
  }, []);

  useEffect(() => {
    if (!id) return;
    let vivo = true;
    setSala(null); setMatriz(null); setErroSala(false);
    (async () => {
      try {
        const sRes = await API.salas.buscarPorId(id);
        if (!vivo) return;
        setSala(sRes);
        await carregarGrade(id);
      } catch {
        if (vivo) setErroSala(true);
      }
    })();
    return () => { vivo = false; };
  }, [id, carregarGrade]);

  const linhas = useMemo(() => (sala && matriz && matriz.length ? montarLinhas(sala, matriz) : []), [sala, matriz]);
  const semGrade = sala && matriz && matriz.length === 0;
  const podeEditar = tipo !== "aluno";

  const gerarOuRecalcular = async () => {
    if (!sala) return;
    setGerando(true);
    try {
      const materias = await API.materias.listar();
      const professores = await API.professores.listar();
      if (!materias.length) {
        Alert.alert("Aviso", "Nenhuma matéria cadastrada no banco de dados.");
        return;
      }
      const total = (sala.quant_aula || 5) * 5;
      const payload = Array.from({ length: total }, (_, i) => {
        const mat = materias[i % materias.length];
        const prof = professores.length ? professores[i % professores.length] : null;
        return {
          id_materia: { id_materia: mat.id_materia },
          id_professor: prof ? { id_professor: prof.id_professor } : null,
        };
      });
      const res = await API.grade.gerar(sala.id_sala, payload);
      if (res.ok) {
        Alert.alert("Sucesso", "Grade horária gerada e salva com sucesso!");
        await carregarGrade(sala.id_sala);
      } else {
        Alert.alert("Erro", "Ocorreu um erro ao processar a grade no servidor.");
      }
    } catch (e) {
      Alert.alert("Erro", "Erro ao conectar com o motor de grade: " + e.message);
    } finally {
      setGerando(false);
    }
  };

  const apagarSala = () => {
    if (!sala) return;
    Alert.alert("Confirmar exclusão", `Deseja realmente deletar a sala "${sala.nome_sala}"?`, [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Excluir", style: "destructive", onPress: async () => {
          try {
            const res = await API.salas.deletar(sala.id_sala);
            if (res.ok) {
              navigation.navigate("Salas");
            } else {
              Alert.alert("Erro", "Não foi possível excluir a sala.");
            }
          } catch (e) {
            Alert.alert("Erro", "Erro ao excluir sala: " + e.message);
          }
        }
      },
    ]);
  };

  if (!id) {
    return (
      <View style={s.screen}>
        <Header telemetry="MATRIZ // GRADE ATIVA" />
        <View style={{ padding: 20 }}>
          <Text style={{ color: colors.textSecondary }}>Selecione uma sala no Painel de Salas.</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={s.screen}>
      <Header telemetry="MATRIZ // GRADE ATIVA" />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Tag>Turma / Ambiente Selecionado</Tag>
        <Text style={[s.title, { fontSize: 24, color: colors.neonLime }]}>
          {erroSala ? `Sala #${id}` : sala ? sala.nome_sala : "Carregando..."}
        </Text>
        {sala && (
          <Text style={{ color: colors.textMuted, fontSize: 11, fontFamily: "monospace", marginTop: 4, marginBottom: 16 }}>
            AULAS: {sala.quant_aula || 6} | DURAÇÃO: {sala.duracao_aula || 50}m | INTERVALO: {sala.duracao_intervalo || 20}m | INÍCIO: {formatarHora(sala.inicio_aula)}
          </Text>
        )}

        {sala && podeEditar && (
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10, marginBottom: 20 }}>
            <GhostButton title="⚙️ Configurações" onPress={() => navigation.navigate("ConfigSala", { id: sala.id_sala })} style={{ flex: 1 }} />
            <NeonButton title={gerando ? "Calculando..." : "⚡ Gerar Grade"} onPress={gerarOuRecalcular} loading={gerando} style={{ flex: 1 }} />
          </View>
        )}
        {sala && podeEditar && (
          <TouchableOpacity onPress={apagarSala} style={{ marginBottom: 20 }}>
            <Text style={{ color: "#ff5555", textAlign: "center" }}>🗑️ Excluir Sala</Text>
          </TouchableOpacity>
        )}

        {erroSala && <Text style={{ color: "#ff9999" }}>Falha ao carregar dados da sala.</Text>}

        {semGrade && (
          <View style={[s.card, { alignItems: "center", marginBottom: 20 }]}>
            <Text style={{ color: colors.textSecondary, marginBottom: 14, textAlign: "center" }}>
              {gradeErro ? "A grade horária para esta sala ainda não foi calculada." : "Esta sala ainda não possui uma grade gerada."}
            </Text>
            {podeEditar && <NeonButton title="⚡ Gerar Grade com Algoritmo CLAEX" onPress={gerarOuRecalcular} loading={gerando} />}
          </View>
        )}

        {!semGrade && sala && matriz && (
          <ScrollView horizontal showsHorizontalScrollIndicator>
            <View>
              <View style={{ flexDirection: "row" }}>
                <View style={[cellHeader, { width: HORA_WIDTH }]}><Text style={headerText}>HORÁRIO</Text></View>
                {DIAS.map((d) => (
                  <View key={d} style={[cellHeader, { width: COL_WIDTH }]}><Text style={headerText}>{d}</Text></View>
                ))}
              </View>
              {linhas.map((l, i) =>
                l.tipo === "intervalo" ? (
                  <View key={i} style={{ flexDirection: "row", backgroundColor: "rgba(0,240,255,0.05)" }}>
                    <View style={[cell, { width: HORA_WIDTH }]}><Text style={{ color: colors.neonLime, fontFamily: "monospace", fontSize: 11 }}>{l.hora}</Text></View>
                    <View style={[cell, { width: COL_WIDTH * 5, alignItems: "center" }]}>
                      <Text style={{ color: colors.neonLime, fontSize: 11, fontFamily: "monospace" }}>☕ INTERVALO ({l.duracao}m)</Text>
                    </View>
                  </View>
                ) : (
                  <View key={i} style={{ flexDirection: "row" }}>
                    <View style={[cell, { width: HORA_WIDTH }]}>
                      <Text style={{ color: colors.neonCyan, fontFamily: "monospace", fontSize: 11 }}>{l.hora}</Text>
                    </View>
                    {l.aulas.map((aula, d) => (
                      <View key={d} style={[cell, { width: COL_WIDTH }]}>
                        {aula?.id_materia ? (
                          <View style={{ backgroundColor: "rgba(210,255,0,0.08)", borderRadius: 6, padding: 6 }}>
                            <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 12 }}>
                              {aula.id_materia.nome_materia || "Aula"}
                            </Text>
                            {aula.id_professor?.nome_professor && (
                              <Text style={{ color: colors.neonLime, fontSize: 10, fontFamily: "monospace", marginTop: 2 }}>
                                {aula.id_professor.nome_professor}
                              </Text>
                            )}
                          </View>
                        ) : (
                          <Text style={{ color: colors.textMuted, fontStyle: "italic", fontSize: 11 }}>Disponível</Text>
                        )}
                      </View>
                    ))}
                  </View>
                )
              )}
            </View>
          </ScrollView>
        )}
      </ScrollView>
    </View>
  );
}

const cellBase = {
  borderWidth: 1,
  borderColor: colors.border,
  padding: 10,
  justifyContent: "center",
};
const cell = { ...cellBase };
const cellHeader = { ...cellBase, backgroundColor: colors.bgCarbon };
const headerText = { color: colors.neonLime, fontWeight: "700", fontSize: 11, textAlign: "center" };
