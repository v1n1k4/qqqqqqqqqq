import { useEffect, useState, useCallback } from "react";
import { View, Text, FlatList, TouchableOpacity, RefreshControl } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, ErrorBox } from "../components/UI";
import { useAuth } from "../context/AuthContext";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

export default function SalasScreen({ navigation }) {
  const { user, tipo } = useAuth();
  const [salas, setSalas] = useState(null);
  const [erro, setErro] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const carregar = useCallback(async () => {
    try {
      const lista = await API.salas.listar();
      setSalas(lista || []);
      setErro(null);
    } catch (e) {
      setErro(e.message);
    }
  }, []);

  useEffect(() => { carregar(); }, [carregar]);

  const podeAdicionar = tipo !== "aluno" && tipo !== "professor";

  return (
    <View style={s.screen}>
      <Header telemetry="SALAS // DASHBOARD" />
      <View style={{ padding: 20, paddingBottom: 0 }}>
        <Tag>Unidade Conectada</Tag>
        <Text style={[s.title, { fontSize: 22 }]}>
          {user?.nome ? `${user.nome} (${user.tipo})` : "Centro Paula Souza"}
        </Text>

        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 20, marginBottom: 12 }}>
          <Text style={{ color: colors.textPure, fontSize: 18, fontWeight: "700" }}>Salas Disponíveis</Text>
          {podeAdicionar && (
            <TouchableOpacity onPress={() => navigation.navigate("NovaSala")}>
              <Text style={{ color: colors.neonLime, fontWeight: "700" }}>+ Nova Sala</Text>
            </TouchableOpacity>
          )}
        </View>

        {erro && <ErrorBox>{"Falha de comunicação com o banco de dados: " + erro}</ErrorBox>}
      </View>

      <FlatList
        data={salas || []}
        keyExtractor={(item) => String(item.id_sala)}
        contentContainerStyle={{ padding: 20, paddingTop: 0 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await carregar(); setRefreshing(false); }} />}
        ListEmptyComponent={
          !erro && (
            <View style={{ padding: 30, alignItems: "center" }}>
              <Text style={{ color: colors.textSecondary }}>
                {salas === null ? "Conectando ao banco de dados..." : "Nenhuma sala encontrada."}
              </Text>
            </View>
          )
        }
        renderItem={({ item: sala }) => {
          const escolaNome = sala.escola?.nome || "Instituição";
          return (
            <TouchableOpacity
              style={[s.card, { marginBottom: 12 }]}
              onPress={() => navigation.navigate("Grade", { id: sala.id_sala })}
            >
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 8 }}>
                <Text style={{ color: colors.textMuted, fontSize: 11 }}>SALA #{sala.id_sala}</Text>
                <Text style={{ color: colors.neonLime, fontSize: 12 }}>VER GRADE →</Text>
              </View>
              <Text style={{ color: colors.textPure, fontSize: 16, fontWeight: "700" }}>{sala.nome_sala}</Text>
              <Text style={{ color: colors.textSecondary, fontSize: 12, marginTop: 6 }}>
                {sala.quant_aula || 6} aulas/dia • {sala.duracao_aula || 50}min • {escolaNome}
              </Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}
