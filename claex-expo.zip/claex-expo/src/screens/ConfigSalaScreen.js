import { useEffect, useState } from "react";
import { View, Text, ScrollView, Alert } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, Field } from "../components/UI";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const formatarHoraParaInput = (h) => (h ? h.substring(0, 5) : "08:00");

export default function ConfigSalaScreen({ route, navigation }) {
  const { id } = route.params || {};
  const [sala, setSala] = useState(null);
  const [form, setForm] = useState({ nome: "", duracaoAula: "50", duracaoIntervalo: "20", inicioAula: "08:00", quantAulas: "6" });
  const [salvando, setSalvando] = useState(false);

  const set = (campo) => (valor) => setForm((f) => ({ ...f, [campo]: valor }));

  useEffect(() => {
    if (!id) {
      Alert.alert("Erro", "ID da sala não especificado.");
      navigation.replace("Salas");
      return;
    }
    let vivo = true;
    API.salas.buscarPorId(id)
      .then((sRes) => {
        if (!vivo || !sRes) return;
        setSala(sRes);
        setForm({
          nome: sRes.nome_sala || "",
          duracaoAula: String(sRes.duracao_aula || 50),
          duracaoIntervalo: String(sRes.duracao_intervalo || 20),
          inicioAula: formatarHoraParaInput(sRes.inicio_aula),
          quantAulas: String(sRes.quant_aula || 6),
        });
      })
      .catch((e) => Alert.alert("Erro", "Erro ao buscar informações da sala: " + e.message));
    return () => { vivo = false; };
  }, [id]);

  const submit = async () => {
    if (!id) return;
    setSalvando(true);

    let inicio = form.inicioAula;
    if (inicio && inicio.length === 5) inicio += ":00";

    const atualizada = {
      nome_sala: form.nome.trim(),
      duracao_aula: parseInt(form.duracaoAula, 10),
      duracao_intervalo: parseInt(form.duracaoIntervalo, 10),
      inicio_aula: inicio,
      quant_aula: parseInt(form.quantAulas, 10),
    };
    if (sala?.escola) atualizada.escola = sala.escola;

    try {
      await API.salas.atualizar(id, atualizada);
      Alert.alert("Sucesso", "Sala atualizada com sucesso!");
      navigation.navigate("Salas");
    } catch (err) {
      Alert.alert("Erro", "Erro ao atualizar sala: " + err.message);
      setSalvando(false);
    }
  };

  return (
    <View style={s.screen}>
      <Header telemetry="SALA // CONFIGURAÇÕES" />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Tag>[Ajuste de Parâmetros]</Tag>
        <Text style={[s.title, { fontSize: 24, marginBottom: 6 }]}>Configuração da Sala</Text>
        <Text style={{ color: colors.textSecondary, marginBottom: 20 }}>
          Altere horários, intervalos e regras de temporização desta turma.
        </Text>

        <Field label="Nome da Sala" value={form.nome} onChangeText={set("nome")} />
        <Field label="Duração de uma Aula (min)" keyboardType="numeric" value={form.duracaoAula} onChangeText={set("duracaoAula")} />
        <Field label="Duração do Intervalo (min)" keyboardType="numeric" value={form.duracaoIntervalo} onChangeText={set("duracaoIntervalo")} />
        <Field label="Hora de Início da Aula" value={form.inicioAula} onChangeText={set("inicioAula")} />
        <Field label="Quantidade de Aulas por Dia" keyboardType="numeric" value={form.quantAulas} onChangeText={set("quantAulas")} />

        <NeonButton
          title={salvando ? "Atualizando..." : "⚡ Atualizar Dados"}
          onPress={submit}
          loading={salvando}
          style={{ marginTop: 12 }}
        />
      </ScrollView>
    </View>
  );
}
