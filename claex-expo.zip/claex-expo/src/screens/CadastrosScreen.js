import { useCallback, useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, Modal, Alert } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, GhostButton, Field, SelectField } from "../components/UI";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const badgeColor = (tipo) =>
  tipo === "escola" ? colors.neonCyan : tipo === "professor" ? colors.neonLime : "#c499ff";

const TIPOS = [
  { label: "Aluno", value: "aluno" },
  { label: "Professor", value: "professor" },
  { label: "Escola", value: "escola" },
];

export default function CadastrosScreen() {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState(false);
  const [senhasVisiveis, setSenhasVisiveis] = useState({});
  const [edicao, setEdicao] = useState(null);
  const [exclusaoId, setExclusaoId] = useState(null);
  const [salvando, setSalvando] = useState(false);
  const [excluindo, setExcluindo] = useState(false);

  const listar = useCallback(async () => {
    try {
      const lista = await API.cadastros.listar();
      setDados(lista || []);
      setErro(false);
    } catch {
      setErro(true);
    }
  }, []);

  useEffect(() => { listar(); }, [listar]);

  const salvarEdicao = async () => {
    const nome = edicao.nome.trim();
    const senha = edicao.senha.trim();
    if (!nome) return Alert.alert("Atenção", "Preencha o nome.");
    if (!senha) return Alert.alert("Atenção", "Preencha a nova senha.");
    setSalvando(true);
    try {
      const res = await API.cadastros.atualizar(edicao.id, nome, senha, edicao.tipo);
      if (!res.ok) throw new Error("Status " + res.status);
      setEdicao(null);
      listar();
    } catch {
      Alert.alert("Erro", "Erro ao atualizar cadastro.");
    } finally {
      setSalvando(false);
    }
  };

  const confirmarExclusao = async () => {
    setExcluindo(true);
    try {
      const res = await API.cadastros.deletar(exclusaoId);
      if (!res.ok) throw new Error("Erro no servidor ao deletar.");
      setExclusaoId(null);
      listar();
    } catch {
      Alert.alert("Erro", "Erro ao excluir cadastro.");
    } finally {
      setExcluindo(false);
    }
  };

  return (
    <View style={s.screen}>
      <Header telemetry="DATABASE // ENTIDADES" />
      <View style={{ padding: 20, paddingBottom: 0, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
        <View>
          <Tag>Registros do Sistema</Tag>
          <Text style={[s.title, { fontSize: 20 }]}>Gestão de Cadastros</Text>
        </View>
        <TouchableOpacity onPress={listar}>
          <Text style={{ color: colors.textSecondary }}>↻ Atualizar</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={dados || []}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 20 }}
        ListEmptyComponent={
          <Text style={{ color: colors.textSecondary, textAlign: "center", padding: 30 }}>
            {erro ? "Falha ao conectar com o banco de dados." : dados === null ? "Sincronizando..." : "Nenhum cadastro encontrado."}
          </Text>
        }
        renderItem={({ item: c }) => {
          const id = String(c.id);
          const visivel = senhasVisiveis[id];
          return (
            <View style={[s.card, { marginBottom: 12 }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 6 }}>
                <Text style={{ color: colors.neonCyan, fontFamily: "monospace", fontSize: 11 }}>#{id}</Text>
                <Text style={{ color: badgeColor(c.tipo), fontSize: 11, textTransform: "uppercase", fontWeight: "700" }}>{c.tipo || "aluno"}</Text>
              </View>
              <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 15 }}>{c.nome}</Text>
              <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 6 }}>{c.email}</Text>
              <TouchableOpacity onPress={() => setSenhasVisiveis((sV) => ({ ...sV, [id]: !sV[id] }))}>
                <Text style={{ color: colors.textMuted, fontFamily: "monospace", fontSize: 12 }}>
                  {visivel ? c.senha || "" : "•••••••• (toque para revelar)"}
                </Text>
              </TouchableOpacity>
              <View style={{ flexDirection: "row", gap: 16, marginTop: 10 }}>
                <TouchableOpacity onPress={() => setEdicao({ id, nome: c.nome || "", senha: "", tipo: c.tipo || "aluno" })}>
                  <Text style={{ color: colors.neonCyan }}>✏️ Editar</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setExclusaoId(id)}>
                  <Text style={{ color: "#ff6666" }}>🗑️ Excluir</Text>
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
      />

      <Modal visible={!!edicao} transparent animationType="fade" onRequestClose={() => setEdicao(null)}>
        <View style={modalOverlay}>
          <View style={[s.card, { width: "100%", maxWidth: 420 }]}>
            <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 16, marginBottom: 14 }}>✏️ Editar Cadastro</Text>
            {edicao && (
              <>
                <Field label="Nome Completo" value={edicao.nome} onChangeText={(t) => setEdicao({ ...edicao, nome: t })} />
                <Field label="Nova Senha" value={edicao.senha} onChangeText={(t) => setEdicao({ ...edicao, senha: t })} secureTextEntry />
                <SelectField label="Tipo de Perfil" selectedValue={edicao.tipo} onValueChange={(v) => setEdicao({ ...edicao, tipo: v })} items={TIPOS} />
              </>
            )}
            <View style={{ flexDirection: "row", gap: 10, marginTop: 10 }}>
              <GhostButton title="Cancelar" onPress={() => setEdicao(null)} style={{ flex: 1 }} />
              <NeonButton title="Salvar" onPress={salvarEdicao} loading={salvando} style={{ flex: 1 }} />
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={!!exclusaoId} transparent animationType="fade" onRequestClose={() => setExclusaoId(null)}>
        <View style={modalOverlay}>
          <View style={[s.card, { width: "100%", maxWidth: 420, alignItems: "center" }]}>
            <Text style={{ fontSize: 32, marginBottom: 8 }}>⚠️</Text>
            <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 16, marginBottom: 4 }}>Deseja excluir este cadastro?</Text>
            <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 16, textAlign: "center" }}>
              Esta ação removerá o registro e suas dependências de horários.
            </Text>
            <View style={{ flexDirection: "row", gap: 10, width: "100%" }}>
              <GhostButton title="Cancelar" onPress={() => setExclusaoId(null)} style={{ flex: 1 }} />
              <NeonButton title={excluindo ? "Excluindo..." : "Sim, excluir"} onPress={confirmarExclusao} loading={excluindo} style={{ flex: 1, backgroundColor: colors.neonRed }} />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const modalOverlay = {
  flex: 1,
  backgroundColor: "rgba(0,0,0,0.75)",
  justifyContent: "center",
  alignItems: "center",
  padding: 20,
};
