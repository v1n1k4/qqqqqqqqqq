import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Linking } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, GhostButton } from "../components/UI";
import { colors, commonStyles as s } from "../theme";

const SLOTS_INICIAIS = [
  { id: 1, materia: "Matemática", estado: "conflict", nota: "Prof. em 2 escolas" },
  { id: 2, materia: "Física", estado: "resolved" },
  { id: 3, materia: "Química", estado: "free" },
  { id: 4, materia: "História", estado: "resolved" },
  { id: 5, materia: "Biologia", estado: "conflict", nota: "Sobreposição" },
  { id: 6, materia: "Português", estado: "resolved" },
];
const ESTADOS = {
  conflict: { badge: "CHOQUE!", cor: "#ff9999", bg: "rgba(255,59,48,0.12)" },
  resolved: { badge: "OK", cor: "#ccff66", texto: "Confirmado", bg: "rgba(210,255,0,0.06)" },
  free: { badge: "LIVRE", cor: colors.textMuted, texto: "Disponível", bg: "rgba(255,255,255,0.03)" },
};
const PROXIMO = { conflict: "resolved", resolved: "free", free: "conflict" };

function Simulador() {
  const [slots, setSlots] = useState(SLOTS_INICIAIS);
  const conflitos = slots.filter((s) => s.estado === "conflict").length;
  const status = conflitos > 0
    ? `ALERTA: ${conflitos} CHOQUE${conflitos > 1 ? "S" : ""} DETECTADO${conflitos > 1 ? "S" : ""}`
    : "SISTEMA OTIMIZADO: ZERO CONFLITOS";

  const alternar = (id) =>
    setSlots((l) => l.map((s) => (s.id === id ? { ...s, estado: PROXIMO[s.estado] } : s)));
  const otimizar = () =>
    setSlots((l) => l.map((s) => (s.estado === "conflict" ? { ...s, estado: "resolved" } : s)));

  return (
    <View style={[s.card, { marginBottom: 24 }]}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <Text style={{ color: colors.textPure, fontWeight: "700" }}>● SIMULADOR DE CONFLITOS</Text>
        <Tag>Interativo</Tag>
      </View>
      <Text style={{ color: colors.textSecondary, fontSize: 12, marginBottom: 12 }}>
        Toque nos horários para simular ou resolver choques de professores entre escolas:
      </Text>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
        {slots.map((sl) => {
          const est = ESTADOS[sl.estado];
          return (
            <TouchableOpacity
              key={sl.id}
              onPress={() => alternar(sl.id)}
              style={{ width: "31%", backgroundColor: est.bg, borderRadius: 8, padding: 8 }}
            >
              <Text style={{ color: est.cor, fontSize: 10, fontWeight: "700", marginBottom: 4 }}>{est.badge}</Text>
              <Text style={{ color: colors.textPure, fontSize: 12, fontWeight: "600" }}>{sl.materia}</Text>
              <Text style={{ color: est.cor, fontSize: 9, marginTop: 2 }}>
                {sl.estado === "conflict" ? sl.nota : est.texto}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <Text style={{ color: colors.textPure, fontWeight: "700", marginBottom: 12, fontSize: 12 }}>{status}</Text>
      <NeonButton title="⚡ Executar Otimização Automática" onPress={otimizar} />
    </View>
  );
}

const LAPS = [
  { badge: "LAP 01 // INPUT", titulo: "Cadastro dos Recursos", texto: "Cadastre instituições, salas, professores, disponibilidades e duração das aulas." },
  { badge: "LAP 02 // PARÂMETROS", titulo: "Definição das Regras", texto: "Configure a carga de matérias, intervalos pedagógicos e restrições de cada docente." },
  { badge: "LAP 03 // RESOLUÇÃO", titulo: "Geração & Distribuição", texto: "O motor CLAEX processa tudo em paralelo e gera uma grade limpa e livre de conflitos." },
];

const EQUIPE = [
  { nome: "Daniel", badge: "BACK-END LEAD", cargo: "Dev Back-End", link: "https://br.linkedin.com/in/daniel-da-silva-pereira-2ab525352?trk=people-guest_people_search-card" },
  { nome: "Vini", badge: "FULL-STACK & UI", cargo: "Dev Front-End & Back-End", link: "https://br.linkedin.com/in/vinicius-castilho-39153b358?trk=people-guest_people_search-card" },
  { nome: "Samuel", badge: "FULL-STACK DEV", cargo: "Desenvolvedor Full-Stack", link: "https://br.linkedin.com/in/samuel-arthur-barbosa-50ba37359" },
];

export default function HomeScreen({ navigation }) {
  return (
    <View style={s.screen}>
      <Header telemetry="AUTOMAÇÃO v3.0" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
        <Tag>[Motor Matricial // Tempo Real]</Tag>
        <Text style={[s.title, { fontSize: 30, marginBottom: 12 }]}>
          Organizar grades horárias{"\n"}
          <Text style={{ color: colors.neonLime }}>nunca foi tão rápido.</Text>
        </Text>
        <Text style={{ color: colors.textSecondary, marginBottom: 20, lineHeight: 20 }}>
          O CLAEX unifica a disponibilidade de professores entre instituições de ensino, eliminando
          choques de horários e automatizando a montagem da grade.
        </Text>

        <View style={{ flexDirection: "row", gap: 12, marginBottom: 24 }}>
          <NeonButton title="Começar Agora →" onPress={() => navigation.navigate("Cadastro")} style={{ flex: 1 }} />
          <GhostButton title="Ver Salas" onPress={() => navigation.navigate("Salas")} style={{ flex: 1 }} />
        </View>

        <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 28 }}>
          {[["0%", "Conflitos de Horário"], ["<1s", "Processamento"], ["100%", "Sincronização"]].map(([n, l]) => (
            <View key={l} style={{ alignItems: "center", flex: 1 }}>
              <Text style={{ color: colors.neonLime, fontWeight: "800", fontSize: 20 }}>{n}</Text>
              <Text style={{ color: colors.textMuted, fontSize: 10, textAlign: "center", marginTop: 2 }}>{l}</Text>
            </View>
          ))}
        </View>

        <Simulador />

        <Tag>[Fluxo Operacional]</Tag>
        <Text style={[s.title, { fontSize: 20, marginBottom: 16 }]}>Como o CLAEX Funciona</Text>
        {LAPS.map((l) => (
          <View key={l.badge} style={[s.card, { marginBottom: 12 }]}>
            <Text style={{ color: colors.neonCyan, fontSize: 10, fontFamily: "monospace", marginBottom: 6 }}>{l.badge}</Text>
            <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 15, marginBottom: 4 }}>{l.titulo}</Text>
            <Text style={{ color: colors.textSecondary, fontSize: 13 }}>{l.texto}</Text>
          </View>
        ))}

        <Tag>[Pit Crew // Engenharia]</Tag>
        <Text style={[s.title, { fontSize: 20, marginBottom: 16 }]}>Desenvolvedores do Projeto</Text>
        {EQUIPE.map((p) => (
          <View key={p.nome} style={[s.card, { marginBottom: 12 }]}>
            <Text style={{ color: colors.neonLime, fontSize: 10, marginBottom: 4 }}>{p.badge}</Text>
            <Text style={{ color: colors.textPure, fontWeight: "700", fontSize: 16 }}>{p.nome}</Text>
            <Text style={{ color: colors.textSecondary, fontSize: 13, marginBottom: 8 }}>{p.cargo}</Text>
            <TouchableOpacity onPress={() => Linking.openURL(p.link)}>
              <Text style={{ color: colors.neonCyan, fontSize: 13 }}>Conectar no LinkedIn ↗</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
