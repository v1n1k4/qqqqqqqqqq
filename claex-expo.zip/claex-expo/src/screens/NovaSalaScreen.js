import { useEffect, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Alert } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, Field, SelectField } from "../components/UI";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

const ESCOLA_PADRAO = [{ id: 1, nome: "Escola Padrão (ID 1)" }];
let seq = 0;
const novaAlocacao = () => ({ key: ++seq, materia: "", professor: "" });

export default function NovaSalaScreen({ navigation }) {
  const [form, setForm] = useState({
    nome: "", idEscola: "", duracaoAula: "50", duracaoIntervalo: "20", inicioAula: "07:30", quantAulas: "6",
  });
  const [escolas, setEscolas] = useState(null);
  const [materias, setMaterias] = useState([]);
  const [professores, setProfessores] = useState([]);
  const [alocacoes, setAlocacoes] = useState([]);
  const [salvando, setSalvando] = useState(false);
  const [etapa, setEtapa] = useState("");

  const set = (campo) => (valor) => setForm((f) => ({ ...f, [campo]: valor }));

  useEffect(() => {
    let vivo = true;
    (async () => {
      let lista = ESCOLA_PADRAO;
      try {
        const cadastros = await API.cadastros.listar();
        const soEscolas = cadastros.filter((c) => c.tipo === "escola");
        if (soEscolas.length) lista = soEscolas;
        else if (cadastros.length) lista = cadastros.map((c) => ({ id: c.id, nome: `${c.nome} (${c.tipo})` }));
      } catch (e) { /* mantém padrão */ }
      if (!vivo) return;
      setEscolas(lista);
      setForm((f) => ({ ...f, idEscola: String(lista[0].id) }));

      try {
        const [mats, profs] = await Promise.all([API.materias.listar(), API.professores.listar()]);
        if (!vivo) return;
        setMaterias(mats);
        setProfessores(profs);
        if (mats.length > 0) setAlocacoes([novaAlocacao()]);
      } catch (e) { /* ignora */ }
    })();
    return () => { vivo = false; };
  }, []);

  const setAloc = (key, campo, valor) =>
    setAlocacoes((l) => l.map((a) => (a.key === key ? { ...a, [campo]: valor } : a)));

  const submit = async () => {
    if (!form.nome.trim()) {
      Alert.alert("Atenção", "Informe o nome da sala.");
      return;
    }
    setSalvando(true);
    setEtapa("Salvando Sala no Banco de Dados...");

    let inicio = form.inicioAula;
    if (inicio && inicio.length === 5) inicio += ":00";

    const sala = {
      nome_sala: form.nome.trim(),
      duracao_aula: parseInt(form.duracaoAula, 10),
      duracao_intervalo: parseInt(form.duracaoIntervalo, 10),
      inicio_aula: inicio,
      quant_aula: parseInt(form.quantAulas, 10),
      escola: { id: parseInt(form.idEscola || "1", 10) },
    };

    try {
      const salva = await API.salas.salvar(sala);
      const idSala = salva.id_sala;

      const payload = alocacoes
        .filter((a) => a.materia)
        .map((a) => ({
          id_materia: { id_materia: parseInt(a.materia, 10) },
          id_professor: a.professor ? { id_professor: parseInt(a.professor, 10) } : null,
        }));

      if (payload.length > 0) {
        setEtapa("Calculando e Gerando Grade Horária...");
        await API.grade.gerar(idSala, payload);
      }

      Alert.alert("Sucesso", "Sala criada com sucesso no banco de dados!");
      navigation.navigate("Grade", { id: idSala });
    } catch (err) {
      Alert.alert("Erro", "Erro ao conectar com o banco de dados: " + err.message);
      setSalvando(false);
    }
  };

  return (
    <View style={s.screen}>
      <Header telemetry="CADASTRO // NOVA SALA" />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Tag>[Configurador de Ambiente]</Tag>
        <Text style={[s.title, { fontSize: 24, marginBottom: 6 }]}>Cadastrar Nova Sala</Text>
        <Text style={{ color: colors.textSecondary, marginBottom: 20 }}>
          Defina os parâmetros de temporização e associe disciplinas e docentes.
        </Text>

        <Field label="Nome da Sala / Turma" placeholder="Ex: 3º Ano Ensino Médio A" value={form.nome} onChangeText={set("nome")} />
        <SelectField
          label="Instituição / Escola"
          selectedValue={form.idEscola}
          onValueChange={set("idEscola")}
          items={(escolas || []).map((e) => ({ label: e.nome, value: String(e.id) }))}
        />
        <Field label="Duração de uma Aula (min)" placeholder="50" keyboardType="numeric" value={String(form.duracaoAula)} onChangeText={set("duracaoAula")} />
        <Field label="Duração do Intervalo (min)" placeholder="20" keyboardType="numeric" value={String(form.duracaoIntervalo)} onChangeText={set("duracaoIntervalo")} />
        <Field label="Hora de Início das Aulas" placeholder="07:30" value={form.inicioAula} onChangeText={set("inicioAula")} />
        <Field label="Quantidade de Aulas por Dia" placeholder="6" keyboardType="numeric" value={String(form.quantAulas)} onChangeText={set("quantAulas")} />

        <View style={{ marginTop: 20, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 20 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <Text style={{ color: colors.textPure, fontSize: 16, fontWeight: "700" }}>Matérias & Docentes</Text>
            <TouchableOpacity onPress={() => setAlocacoes((l) => [...l, novaAlocacao()])}>
              <Text style={{ color: colors.neonLime, fontWeight: "700" }}>+ Adicionar</Text>
            </TouchableOpacity>
          </View>

          {alocacoes.map((a) => (
            <View key={a.key} style={[s.card, { marginBottom: 12 }]}>
              <SelectField
                label="Disciplina"
                selectedValue={a.materia}
                onValueChange={(v) => setAloc(a.key, "materia", v)}
                items={[{ label: "Selecione a matéria", value: "" }, ...materias.map((m) => ({ label: m.nome_materia, value: String(m.id_materia) }))]}
              />
              <SelectField
                label="Professor Responsável"
                selectedValue={a.professor}
                onValueChange={(v) => setAloc(a.key, "professor", v)}
                items={[{ label: "Selecione o professor", value: "" }, ...professores.map((p) => ({ label: p.nome_professor, value: String(p.id_professor) }))]}
              />
            </View>
          ))}
        </View>

        <NeonButton
          title={salvando ? etapa : "⚡ Gravar Sala & Gerar Grade"}
          onPress={submit}
          loading={salvando}
          style={{ marginTop: 12 }}
        />
      </ScrollView>
    </View>
  );
}
