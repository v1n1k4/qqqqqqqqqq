import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import Header from "../components/Header";
import { Tag, NeonButton, Field, ErrorBox } from "../components/UI";
import { useAuth } from "../context/AuthContext";
import { API } from "../api";
import { colors, commonStyles as s } from "../theme";

export default function LoginScreen({ navigation }) {
  const { refresh } = useAuth();
  const [login, setLogin] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  const mostrarErro = (texto) => setErro("❌ " + texto);

  const entrar = async () => {
    if (!login.trim() || !senha.trim()) {
      mostrarErro("Preencha o usuário e a senha!");
      return;
    }
    setLoading(true);
    setErro("");
    try {
      const result = await API.login(login.trim(), senha.trim());
      if (result.ok) {
        refresh();
        navigation.reset({ index: 0, routes: [{ name: "Salas" }] });
        return;
      } else if (result.status === 404) {
        mostrarErro(result.data?.erro || "Usuário não encontrado no banco de dados!");
      } else if (result.status === 401) {
        mostrarErro(result.data?.erro || "Senha incorreta!");
      } else {
        mostrarErro("Erro inesperado ao validar credenciais.");
      }
    } catch (e) {
      mostrarErro("Erro de comunicação com o servidor Spring Boot! Verifique se a API está online.");
    }
    setLoading(false);
  };

  return (
    <View style={s.screen}>
      <Header telemetry="ACESSO // SEGURANÇA" />
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Tag>[Autenticação Central]</Tag>
        <Text style={[s.title, { fontSize: 30, marginBottom: 10 }]}>
          Bem-vindo à <Text style={{ color: colors.neonLime }}>CLAEX</Text>
        </Text>
        <Text style={{ color: colors.textSecondary, marginBottom: 24 }}>
          Acesse sua conta para gerenciar horários, disponibilidade de docentes e otimizar salas em tempo real.
        </Text>

        <View style={[s.card, { marginBottom: 20 }]}>
          <Tag>Portal do Usuário</Tag>
          <Text style={{ color: colors.textPure, fontSize: 20, fontWeight: "700", marginBottom: 16 }}>
            Entrar no Sistema
          </Text>

          <Field
            label="Nome de Usuário"
            placeholder="Ex: Nome cadastrado no banco"
            value={login}
            onChangeText={(t) => { setLogin(t); setErro(""); }}
            autoCapitalize="none"
          />
          <Field
            label="Senha"
            placeholder="Sua senha de acesso"
            value={senha}
            onChangeText={(t) => { setSenha(t); setErro(""); }}
            secureTextEntry
          />

          <ErrorBox>{erro}</ErrorBox>

          <NeonButton
            title={loading ? "Verificando..." : "Entrar no Sistema"}
            onPress={entrar}
            loading={loading}
            style={{ marginTop: 8 }}
          />

          <TouchableOpacity onPress={() => navigation.navigate("Cadastro")} style={{ marginTop: 16 }}>
            <Text style={{ color: colors.textSecondary, textAlign: "center" }}>
              Não possui uma conta?{" "}
              <Text style={{ color: colors.neonLime, fontWeight: "700" }}>Cadastre-se aqui</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}
