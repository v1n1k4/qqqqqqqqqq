// ============================================================================
// CLIENTE DE API — CLAEX (Expo/React Native)
//
// ⚠️ IMPORTANTE — LEIA ANTES DE RODAR:
// O projeto original (claex-react) dependia de um arquivo `public/js/api.js`
// que NÃO estava incluído no .zip enviado (ele expunha `window.API` e vinha
// de outro repositório, provavelmente v1n1k4/claex-front ou v1n1k4/zsdbn).
// Não consegui buscar esse arquivo automaticamente, então este cliente foi
// RECONSTRUÍDO a partir do jeito que cada tela chama `API.xxx` no código-fonte,
// usando convenções REST padrão do Spring Boot como melhor palpite.
//
// Antes de usar de verdade, ajuste os itens abaixo:
//   1) BASE_URL: coloque a URL pública do seu backend Railway
//      (repo v1n1k4/lolooo).
//   2) ENDPOINTS: confira cada caminho. A forma mais rápida de confirmar é
//      abrir o site antigo (Vercel) no navegador, abrir o DevTools > Network,
//      usar o sistema normalmente e ver as URLs reais que aparecem lá.
//      Uma pista encontrada no código original aponta para um padrão
//      "*-html" nos controllers (ex: /form_cadastro-html/salvar) — pode ser
//      que TODOS os endpoints sigam esse padrão em vez do REST puro abaixo.
// ============================================================================

import AsyncStorage from "@react-native-async-storage/async-storage";

// 1) Ajuste aqui a URL do backend Spring Boot (Railway):
export const BASE_URL = "https://SEU-BACKEND.up.railway.app";

// 2) Ajuste os caminhos se necessário:
const ENDPOINTS = {
  login: "/login",
  cadastros: "/cadastros",
  salas: "/salas",
  materias: "/materias",
  professores: "/professores",
  grade: (idSala) => `/grade/${idSala}`,
  professorDisponibilidade: "/professor/disponibilidade",
  professorMaterias: "/professor/materias",
};

const STORAGE_KEY = "claex_user";

// Cache em memória do usuário logado, hidratado a partir do AsyncStorage no
// boot do app (ver `hydrateSession` chamado em AuthContext). Isso substitui
// o `sessionStorage` síncrono usado na versão web.
let usuarioAtualCache = null;

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  return { ok: res.ok, status: res.status, data };
}

export const API = {
  // Carregado uma vez no boot do app (ver AuthContext) para popular o cache síncrono.
  async hydrateSession() {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      usuarioAtualCache = raw ? JSON.parse(raw) : null;
    } catch {
      usuarioAtualCache = null;
    }
    return usuarioAtualCache;
  },

  // Mantido síncrono (como na versão web) para não quebrar os componentes
  // que chamam `API.getUsuarioAtual()` diretamente; sempre chame
  // `hydrateSession()` antes, no boot do app.
  getUsuarioAtual() {
    return usuarioAtualCache;
  },

  async logout() {
    usuarioAtualCache = null;
    await AsyncStorage.removeItem(STORAGE_KEY);
  },

  async login(login, senha) {
    const result = await request(ENDPOINTS.login, {
      method: "POST",
      body: JSON.stringify({ login, senha }),
    });
    if (result.ok && result.data) {
      usuarioAtualCache = result.data;
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(result.data));
    }
    return result;
  },

  cadastros: {
    async listar() {
      const r = await request(ENDPOINTS.cadastros);
      return r.data || [];
    },
    async salvar(nome, email, senha, tipo) {
      const r = await request(ENDPOINTS.cadastros, {
        method: "POST",
        body: JSON.stringify({ nome, email, senha, tipo }),
      });
      return { ok: r.ok, status: r.status, msg: r.data?.erro || r.data?.msg };
    },
    async atualizar(id, nome, senha, tipo) {
      return request(`${ENDPOINTS.cadastros}/${id}`, {
        method: "PUT",
        body: JSON.stringify({ nome, senha, tipo }),
      });
    },
    async deletar(id) {
      return request(`${ENDPOINTS.cadastros}/${id}`, { method: "DELETE" });
    },
  },

  salas: {
    async listar() {
      const r = await request(ENDPOINTS.salas);
      return r.data || [];
    },
    async buscarPorId(id) {
      const r = await request(`${ENDPOINTS.salas}/${id}`);
      return r.data;
    },
    async salvar(sala) {
      const r = await request(ENDPOINTS.salas, {
        method: "POST",
        body: JSON.stringify(sala),
      });
      return r.data;
    },
    async atualizar(id, sala) {
      return request(`${ENDPOINTS.salas}/${id}`, {
        method: "PUT",
        body: JSON.stringify(sala),
      });
    },
    async deletar(id) {
      return request(`${ENDPOINTS.salas}/${id}`, { method: "DELETE" });
    },
  },

  materias: {
    async listar() {
      const r = await request(ENDPOINTS.materias);
      return r.data || [];
    },
  },

  professores: {
    async listar() {
      const r = await request(ENDPOINTS.professores);
      return r.data || [];
    },
  },

  grade: {
    async buscar(idSala) {
      const r = await request(ENDPOINTS.grade(idSala));
      if (!r.ok) throw new Error("Grade não encontrada");
      return r.data;
    },
    async gerar(idSala, payload) {
      return request(ENDPOINTS.grade(idSala), {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
  },

  professor: {
    async listarDisponibilidade() {
      const r = await request(ENDPOINTS.professorDisponibilidade);
      return r.data || [];
    },
    async cadastrarDisponibilidade(disp) {
      return request(ENDPOINTS.professorDisponibilidade, {
        method: "POST",
        body: JSON.stringify(disp),
      });
    },
    async deletarDisponibilidade(id) {
      return request(`${ENDPOINTS.professorDisponibilidade}/${id}`, { method: "DELETE" });
    },
    async listarMaterias() {
      const r = await request(ENDPOINTS.professorMaterias);
      return r.data || [];
    },
    async vincularMateria(payload) {
      return request(ENDPOINTS.professorMaterias, {
        method: "POST",
        body: JSON.stringify(payload),
      });
    },
  },
};
