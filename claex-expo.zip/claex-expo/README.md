# CLAEX — Expo (React Native)

Conversão do front-end web (`claex-react`, Vite) para um app Expo/React Native,
mantendo as mesmas telas, fluxos e regras de acesso por tipo de usuário
(escola/administrador, professor, aluno).

## ⚠️ Antes de rodar — 2 ajustes obrigatórios

O projeto original dependia de um arquivo `public/js/api.js` (com a lógica
real de chamadas à API) que **não estava no .zip enviado**. O cliente em
`src/api.js` foi reconstruído a partir de como cada tela chama `API.xxx`,
usando convenções REST como palpite. Antes de usar de verdade:

1. **`src/api.js` → `BASE_URL`**
   Troque `https://SEU-BACKEND.up.railway.app` pela URL pública real do seu
   backend Spring Boot (repo `v1n1k4/lolooo`, no Railway).

2. **`src/api.js` → `ENDPOINTS`**
   Confira se os caminhos (`/login`, `/salas`, `/cadastros`, `/materias`,
   `/professores`, `/grade/:id`, `/professor/...`) batem com os do seu
   backend. A forma mais confiável de confirmar: abra o site antigo
   (Vercel) no navegador, abra o DevTools → aba Network, use o sistema
   normalmente e veja as URLs reais que aparecem nas chamadas.
   Uma pista no código original menciona um controller chamado
   `CadastroHtmlController` mapeado em `/form_cadastro-html/salvar` — pode
   ser que o padrão real seja `*-html` em vez do REST puro que usei aqui.

Sem esses dois ajustes o app abre e navega normalmente, mas as telas que
dependem do banco (Salas, Grade, Cadastros, Login) vão mostrar erro de
conexão.

## Instalar e rodar

```bash
npm install
npx expo start
```

Abra no celular com o app **Expo Go** (escaneando o QR code), ou pressione
`a` / `i` no terminal para abrir num emulador Android/iOS, ou `w` para rodar
no navegador.

## O que mudou em relação à versão web

- **Roteamento**: `react-router-dom` → `@react-navigation/native` (stack).
  As mesmas rotas viraram telas: `/` → Home, `/login` → Login, `/salas` →
  Salas, `/grade?id=` → Grade (agora recebe `id` por parâmetro de rota), etc.
- **Sessão**: `sessionStorage` → `@react-native-async-storage/async-storage`
  (persiste entre aberturas do app, ao contrário da sessão do navegador).
- **Estilos**: classes CSS → `StyleSheet`/objetos de estilo em
  `src/theme.js`, mantendo a paleta neon escura (verde-limão, ciano,
  vermelho) do design original.
- **Formulários**: `<select>` HTML → `@react-native-picker/picker`.
- **Tabelas** (Grade, Cadastros): não existem tabelas HTML no React Native;
  viraram uma grade rolável horizontalmente (Grade) e uma lista de cartões
  (Cadastros).
- **Menu lateral**: viel um `Modal` deslizante, aberto pelo ícone de menu no
  topo (em vez do `<aside>` fixo da web).
- **`window.confirm` / `alert`**: viraram `Alert.alert` do React Native.
- **Fundo animado (`webgl-background.js`)**: não foi portado — WebGL não
  roda de forma nativa no React Native/Expo Go sem bibliotecas extras
  (ex: `expo-gl`), e não fazia parte do arquivo enviado.

## Estrutura

```
App.js
src/
  api.js                 # cliente HTTP (AJUSTAR — ver acima)
  theme.js                # cores e estilos compartilhados
  context/AuthContext.js  # sessão do usuário (AsyncStorage)
  navigation/AppNavigator.js
  components/
    Header.js             # topo + menu lateral
    UI.js                 # botões, campos de texto/seleção
  screens/
    HomeScreen.js
    LoginScreen.js
    CadastroScreen.js
    SalasScreen.js
    GradeScreen.js
    NovaSalaScreen.js
    ConfigSalaScreen.js
    CadastrosScreen.js
    PainelProfessorScreen.js
```
